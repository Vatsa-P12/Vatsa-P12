# CSS 3D Solar System

A Pen created on CodePen.io. Original URL: [https://codepen.io/Vatsa-1414/pen/rNEXwXR](https://codepen.io/Vatsa-1414/pen/rNEXwXR).

Github repo : https://github.com/juliangarnier/3D-CSS-Solar-System
Works better in webkit, buggy in FF, flat in IE. 
Inspired by http://neography.com/experiment/circles/solarsystem/ and http://nicolasgallagher.com/css-pseudo-element-solar-system/demo/
[update] Added some basic responsive styles
